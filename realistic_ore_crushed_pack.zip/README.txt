Crushed deposit item textures.
Location: assets/realisticores/textures/item/
Naming: crushed_<deposit>.png
