Hosted texture pack for realistic ores.
Structure:
assets/realisticores/textures/block/*.png
assets/realisticores/textures/overlays/*.png

Stone variants:
<ore>.png

Deepslate variants:
deepslate_<ore>_bottom.png
deepslate_<ore>_side.png
deepslate_<ore>_top.png
